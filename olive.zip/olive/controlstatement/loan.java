//control statement to check if you are eligible to vote
import java.util.*;
class loan{
public static void main(String[] args){
  Scanner obj=new Scanner(System.in);
 System.out.println("enter salary to check the amount of loan u are allowed");
  int salary=obj.nextInt();

if(salary>50000 && salary<60000){
System.out.println("you are allowed 120000 frw");
}
else if(salary>60000 && salary<70000){
System.out.println("you are allowed 150000 frw");
}
else if(salary>70000 && salary<80000){
System.out.println("you are  allowed 180000 frw");
}
else{
System.out.println("out of bond");
}
}
}