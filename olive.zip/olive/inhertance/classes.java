class school{  
 String name="SFB";
}  
class classes extends school{  
 int classrooms=17;  
 public static void main(String args[]){  
   classes p=new classes();  
   System.out.println("school name is:"+p.name);  
   System.out.println("classes in sfb are:"+p.classrooms);  
}  
}  