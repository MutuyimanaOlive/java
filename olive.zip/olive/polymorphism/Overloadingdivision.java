 //overloading in java

class Overloadingdivision{  
  void add(int a,int b){System.out.println(a/b);}  
  void add(int a,int b,int c){System.out.println(a/b/c);}  
  
  public static void main(String args[]){  
 Overloadingdivision obj=new Overloadingdivision();  
  obj.add(20,2);
  obj.add(20,2,2);  
  
  }  
}  