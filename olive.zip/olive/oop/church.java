 
class church{  

 String churchname="zion temple"; 
 String location="Gatenga";
 
 public static void main(String args[]){  
   church p=new church();  
   System.out.println("church id is:"+p.churchname);  
   System.out.println("church location is:"+p.location);  
   
}  
}  