//control statement


 import java.util.*;

class ifelse{
 public static void main(String[] args){

 Scanner years=new Scanner(System.in);
         
         System.out.println("enter your age please!");
          int age=years.nextInt();

 if(age<18){
 System.out.println("you are not allowed to drink beer");
}
else{
    System.out.println("you are old enougth to drink beer");
}
 
}
}