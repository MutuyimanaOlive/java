//java object and class
// program to access doctor data by using object

class doctor{
 int id=12554;
 String name="mugabo"; 
 String shift="2:00 pm";
}
class printdoctordata{  
   
 public static void main(String args[]){  

  doctor d=new doctor(); //creating patient's object --d--
  System.out.println("doctor information"); 
  System.out.println("__________________"); 
  System.out.println(); 
  System.out.println("doctor id is: "+d.id);  
  System.out.println("doctor name is: "+d.name);  
  System.out.println("doctor shift is at: "+d.shift); 
 }  
}  
