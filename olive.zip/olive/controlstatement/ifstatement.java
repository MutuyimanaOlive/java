//if statement to check if you are allowed to drive
//you can donate if you above 18yrs and above 56 kg


 import java.util.*;

class ifstatement{
 public static void main(String[] args){

 Scanner contractYears=new Scanner(System.in);
Scanner  d=new Scanner(System.in);
         
         System.out.println("enter 1 and press enter to check the type of control statement!");
          int n=d.nextInt();

 if(n==1){
 System.out.println("the type of control statement is: "+ "if statemet");
}
}
}
