//java object and class



class aplicant{  
   int id;
   String email;
   String name;
   String position;
 public static void main(String args[]){  

  aplicant a=new aplicant(); //creating employee object --Emp--
  a.id=234;
  a.name="kagabo";
  a.position="accountant";
  a.email="asdf@gmail.com";

 System.out.println(" aplicant information: ");
System.out.println("*______________________*");  
System.out.println();    
  System.out.println("aplicant id is: "+a.id);  
  System.out.println("aplicant name is: "+a.name);  
  System.out.println("aplicant position is: "+a.position);  
  System.out.println("aplicant salary is: "+a.email);  
 }  
}  